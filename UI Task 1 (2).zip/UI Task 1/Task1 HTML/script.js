
function action(){
        document.getElementById("col").style.right = "0px";
}
function action2(){
    document.getElementById("col").style.right = "-80000px";
}
